"""
Utility functions common to all intern submodules.
"""

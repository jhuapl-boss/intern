class Remote(object):
    def __init__(self):
        pass
